package com.example.appbenhvienlocal;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class PhieuKhamBenh extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phieu_kham_benh);
    }
}