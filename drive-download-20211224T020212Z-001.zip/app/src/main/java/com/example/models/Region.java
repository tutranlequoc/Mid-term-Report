package com.example.models;

public class Region {
    private int regionThumb;

    public Region(int regionThumb) {
        this.regionThumb = regionThumb;
    }

    public int getRegionThumb() {
        return regionThumb;
    }

    public void setRegionThumb(int regionThumb) {
        this.regionThumb = regionThumb;
    }
}
