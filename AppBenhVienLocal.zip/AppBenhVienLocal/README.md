# Mid-term-Report
This is a repository for our mid-term project about a hospital application
We will add more function and activity in the future!!!
Thank u for watching
